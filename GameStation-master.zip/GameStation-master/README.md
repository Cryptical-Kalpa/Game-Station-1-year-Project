# GAMESTATION

----
## JSP/SERVLET WEB APPLICATION
Download [Eclipse JEE](https://www.eclipse.org/downloads/)

Download [Tomcat](https://tomcat.apache.org/download-80.cgi)

Download [XAMPP](https://www.apachefriends.org/download.html)

> This project is developed using Eclipse JEE. Download the required applications from the above links.

----
## Steps
1. Install GameStation
2. Import gamestation.sql
